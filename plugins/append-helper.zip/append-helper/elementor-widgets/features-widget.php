<?php 


class Append_Features_Widget extends \Elementor\Widget_Base {

	public function get_name() {
        return 'append-features-widget';
    }

	public function get_title() {
        return __('Features widget', 'append-helper');
    }

	public function get_icon() {
        return 'eicon-archive-posts';
    }

	protected function register_controls() {

        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Features', 'append-helper' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		

        $this->add_control(
			'fearures_title',
			[
				'label' => esc_html__( 'Features Title', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type title here', 'append-helper' ),
			]
		);

        $this->add_control(
			'fearures_content',
			[
				'label' => esc_html__( 'Features content', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Type title here', 'append-helper' ),
			]
		);

        $this->add_control(
			'fearures_link_page',
			[
				'label' => esc_html__( 'Features Link', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type title here', 'append-helper' ),
			]
		);
        $this->add_control(
			'image_class_1',
            [
                'label' => esc_html__( 'Choose Image', 'append-helper' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
		);
        $this->add_control(
			'image_class_2',
            [
                'label' => esc_html__( 'Choose Image', 'append-helper' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
		);

        $this->end_controls_section();

        


    }

	protected function render() {
        $settings = $this->get_settings_for_display();
		$title = $settings['fearures_title'];
        $content = $settings['fearures_content'];
        $link = $settings['fearures_link_page'];
        $img1 = $settings['image_class_1'];
        $img_url2 = $img1['url'];
        $img2 = $settings['image_class_2'];
        $img_url1 = $img2['url'];



        ?>
        <div class="features-lg ">
            <div class="container">
                <div class="row feature align-items-center justify-content-between">
                    <div class="col-lg-7 section-stack order-lg-2 mb-4 mb-lg-0 position-relative" data-aos="fade-up" data-aos-delay="0">

                        <div class="image-stack">
                            <div class="image-stack__item image-stack__item--top">
                                <img src="<?php echo esc_url($img_url1); ?>" alt="img">
                            </div>
                            <div class="image-stack__item image-stack__item--bottom">
                                <img src="<?php echo esc_url($img_url2); ?>" alt="Img">
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-4 section-title" data-aos="fade-up" data-aos-delay="100">
                        
                        <h2 class="font-weight-bold mb-4 heading"><?php echo esc_html($title); ?></h2>
                        <p class="mb-4"><?php echo esc_html($content); ?></p>
                        <p><a href="<?php echo esc_url($link); ?>" class="btn btn-primary">Get Started</a></p>

                    </div>
                    
                </div>
            </div>
        </div>
        <?php
    }

}


?>