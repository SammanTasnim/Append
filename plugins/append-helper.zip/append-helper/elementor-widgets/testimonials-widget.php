<?php 


class Append_Testimonials_Widget extends \Elementor\Widget_Base {

	public function get_name() {
        return 'append-testimonials-widget';
    }

	public function get_title() {
        return __('Testimonials widget', 'append-helper');
    }

	public function get_icon() {
        return 'eicon-archive-posts';
    }

	protected function register_controls() {




        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'append-helper' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		

        $this->add_control(
			'testimonial_title',
			[
				'label' => esc_html__( 'Testimonail Title', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your text here', 'append-helper' ),
			]
		);

        

        $this->add_control(
			'testimonial_description',
			[
				'label' => esc_html__( 'Description', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'placeholder' => esc_html__( 'Type your description here', 'append-helper' ),
			]
		);

        $repeater = new \Elementor\Repeater();

        

        $repeater->add_control(
			'name',
			[
				'label' => esc_html__( 'Name', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your name here', 'append-helper' ),
			]
		);

        $repeater->add_control(
			'position_description',
			[
				'label' => esc_html__( 'Position Description', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your description here', 'append-helper' ),
			]
		);
        $repeater->add_control(
			'testimonial_content',
			[
				'label' => esc_html__( 'Content', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'placeholder' => esc_html__( 'Type your content here', 'append-helper' ),
			]
		);
        $repeater->add_control(
			'testimonial_image',
            [
                'label' => esc_html__( 'Choose Image', 'append-helper' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
		);

        $this->add_control(
			'service_boxes',
			[
				'label' => esc_html__( 'Service boxes', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ name }}}',
			]
		);

        

        $this->end_controls_section();


       

    }

	protected function render() {
        $settings = $this->get_settings_for_display();
        $title = $settings['testimonial_title'];
        $description = $settings['testimonial_description'];
        $boxes = $settings['service_boxes'];
        
        ?>
        <div class="testimonial-section">
            <div class="container">
                <div class="row align-items-center justify-content-between">
                <div class="col-lg-4 mb-5 section-title" data-aos="fade-up" data-aos-delay="0">
                    
                    <h2 class="mb-4 font-weight-bold heading"><?php echo esc_html($title); ?></h2>
                    <p class="mb-4"><?php echo esc_html($description); ?></p>
                    <p><a href="#" class="btn btn-primary"><?php echo esc_html( 'Product Tour', 'append-helper' ) ?></a></p>
                </div>
                <div class="col-lg-7" data-aos="fade-up" data-aos-delay="100">
                    
                    <div class="testimonial--wrap">
                    <div class="owl-single owl-carousel no-dots no-nav">
                        <?php
                        if (isset($boxes)){
                            foreach($boxes as $box){
                                $author_name = isset($box['name']) ? $box['name'] : '';
                                $author_position = isset($box['position_description']) ? $box['position_description'] : '';
                                $author_content = isset($box['testimonial_content']) ? $box['testimonial_content'] : '';
                                $author_image = isset($box['testimonial_image']) ? $box['testimonial_image'] : '';
                                $author_image_url = $author_image['url'];
                                ?>
                                <div class="testimonial-item">
                                    <div class="d-flex align-items-center mb-4">
                                        <div class="photo mr-3">
                                        <img src="<?php echo esc_url( $author_image_url ); ?>" alt="Image" class="img-fluid">
                                        </div>
                                        <div class="author">
                                            <cite class="d-block mb-0"><?php echo esc_html( $author_name ); ?></cite>
                                            <span><?php echo esc_html( $author_position ); ?></span>
                                        </div>
                                    </div>
                                    <blockquote>
                                        <p>&ldquo;<?php echo esc_html( $author_content ); ?>&rdquo;</p>
                                    </blockquote>
                                </div>
                                <?php
                            }
                        }
                        ?>
                          

                         
                    </div>
                    <div class="custom-nav-wrap">
                        <a href="#" class="custom-owl-prev"><span class="icon-keyboard_backspace"></span></a>
                        <a href="#" class="custom-owl-next"><span class="icon-keyboard_backspace"></span></a>
                    </div>
                    </div>

                </div>
                </div>
            </div>
            </div>
        <?php
    }

}


?>