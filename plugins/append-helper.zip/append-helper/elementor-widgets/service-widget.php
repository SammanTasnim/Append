<?php

class Append_Service_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'append-service-section';
	}

	public function get_title() {
		return __('Service widget', 'append-helper');
	}

	public function get_icon() {
        return 'eicon-archive-posts';
    }

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'append-helper' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		

        $this->add_control(
			'service_title',
			[
				'label' => esc_html__( 'Service Title', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your text here', 'append-helper' ),
			]
		);


        $this->end_controls_section();

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'append-helper' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'icon_class',
			[
				'label' => esc_html__( 'Icon class', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your class name here', 'append-helper' ),
			]
		);

		$repeater->add_control(
			'box_title',
			[
				'label' => esc_html__( 'Box title', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your title here', 'append-helper' ),
			]
		);

		$repeater->add_control(
			'box_content',
			[
				'label' => esc_html__( 'Content', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'placeholder' => esc_html__( 'Type your content here', 'append-helper' ),
			]
		);
		$repeater->add_control(
			'box_link',
			[
				'label' => esc_html__( 'Box link', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'rows' => 10,
				'placeholder' => esc_html__( 'Type your box link here', 'append-helper' ),
			]
		);


		$this->add_control(
			'service_boxes',
			[
				'label' => esc_html__( 'Service boxes', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ box_title }}}',
			]
		);


        $this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
        $title = $settings['service_title'];
        ?> 
        <!-- start service Area -->
        <div class="site-section">
		<div class="container">
			<div class="row mb-5">
			<div class="col-12 text-center"  data-aos="fade-up">
				<h2 class="heading font-weight-bold mb-3"><?php echo esc_html($title); ?></h2>
			</div>
			</div>
			<div class="row align-items-stretch">
				<?php
				$boxes = $settings['service_boxes'];
				if ( is_array($boxes) ){
					foreach($boxes as $box){
						$box_title   = isset($box['box_title']) ? $box['box_title'] : '';
						$icon_class  = isset($box['icon_class']) ? $box['icon_class'] : '';
						$box_content = isset($box['box_content']) ? $box['box_content'] : '';
						$box_link    = isset($box['box_link']) ? $box['box_content'] : '';
						?>
						<div class="col-md-6 col-lg-4 mb-4 mb-lg-4" data-aos="fade-up">
							<div class="unit-4 d-flex">
								<div class="unit-4-icon mr-4">
									<span class="<?php echo esc_attr($icon_class); ?>"></span>
								</div>
								<div>
									<h3><?php echo esc_html($box_title); ?></h3>
									<p><?php echo esc_html( $box_content ); ?></p>
									<p><a href="<?php echo esc_attr($box_link); ?>">Learn More</a></p>
								</div>
							</div>
						</div>
						<?php
					}
				}
				?>
			
			

			</div>
		</div>
		</div>
		<?php

	}



}



?>