<?php 


class Append_Client_Widget extends \Elementor\Widget_Base {

	public function get_name() {
        return 'append-client-widget';
    }

	public function get_title() {
        return __('Client widget', 'append-helper');
    }

	public function get_icon() {
        return 'eicon-archive-posts';
    }

	protected function register_controls() {

        $this->start_controls_section(
			'clients_section',
			[
				'label' => esc_html__( 'Clients', 'append-helper' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'image_class',
            [
                'label' => esc_html__( 'Choose Image', 'append-helper' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
		);
        $this->add_control(
			'client_boxes',
			[
				'label' => esc_html__( 'Image', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ image_class }}}',
			]
		);


        $this->end_controls_section();

    }

	protected function render() {
        $settings = $this->get_settings_for_display();
		?>
                <div class="py-3">
                    <div class="container">

                        <div class="owl-logos owl-carousel">
                            <?php
                            $boxes = $settings['client_boxes'];
                            
                            if(is_array($boxes)){
                            foreach($boxes as $box){
                                $box_image = isset($box['image_class']) ? $box['image_class'] : '';
                                $img_url = $box_image['url'];
                              
                                ?>
                                <div class="item">
                                    <img src="<?php echo esc_url($img_url); ?>" alt="Image" class="img-fluid">
                                </div>
                            <?php
                            }
                    }

                        ?> 
                        </div>
                            
                    </div>
                    
                </div>
              
		<?php
    }

}


?>