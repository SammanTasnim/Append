<?php 


class Append_Plans_Widget extends \Elementor\Widget_Base {

	public function get_name() {
        return 'append-plans-widget';
    }

	public function get_title() {
        return __('Plans widget', 'append-helper');
    }

	public function get_icon() {
        return 'eicon-archive-posts';
    }

	protected function register_controls() {

        $this->start_controls_section(
			'pricing_table',
			[
				'label' => esc_html__( 'Pricing table', 'append-helper' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $repeater = new \Elementor\Repeater();

        //Plan Title
        $repeater->add_control(
			'plan_title',
			[
				'label' => esc_html__( 'Plan Title', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your Plan Title here', 'append-helper' ),
			]
		);
        ////
        //Plan Content
        $repeater->add_control(
			'box_content',
			[
				'label' => esc_html__( 'Content', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'placeholder' => esc_html__( 'Type your plan content here', 'append-helper' ),
			]
		);

        //Plan Price
        
        $repeater->add_control(
			'plan_price_monthly',
			[
				'label' => esc_html__( 'Plan Price Monthly', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your Price monthly here', 'append-helper' ),
			]
		);
        $repeater->add_control(
			'plan_price_yearly',
			[
				'label' => esc_html__( 'Plan Price yearly', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your Price yearly here', 'append-helper' ),
			]
		);

        //plan Benefits one
        $repeater->add_control(
			'plan_box_one_class',
			[
				'label' => esc_html__( 'Plan benefit icon class one', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your Plan benefit one icon class here', 'append-helper' ),
			]
		);
        $repeater->add_control(
			'plan_benefit_content_one',
			[
				'label' => esc_html__( 'plan benefit content one ', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'placeholder' => esc_html__( 'Type your plan benefit here', 'append-helper' ),
			]
		);

        //plan Benefits two
        $repeater->add_control(
			'plan_box_two_class',
			[
				'label' => esc_html__( 'Plan benefit icon class two', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your Plan Plan benefit icon class here', 'append-helper' ),
			]
		);
        $repeater->add_control(
			'plan_benefit_content_two',
			[
				'label' => esc_html__( 'Plan benefit content two', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'placeholder' => esc_html__( 'Type your plan benefit here', 'append-helper' ),
			]
		);

        //Plan link
        $repeater->add_control(
			'plan_box_link',
			[
				'label' => esc_html__( 'Box Link', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your box link here', 'append-helper' ),
			]
		);

        


        $this->add_control(
			'plan_boxes',
			[
				'label' => esc_html__( 'Plan boxes', 'append-helper' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ plan_title }}}',
			]
		);


        $this->end_controls_section();

    }

	protected function render() {
        $settings = $this->get_settings_for_display();
        $boxes = $settings['plan_boxes'];
		?>
            <div class="pricing-section">
                <div class="container">
                    <div class="section-title text-center mb-5" data-aos="fade-up" data-aos-delay="0">
                        <h2 class="heading font-weight-bold mb-5">Plans</h2>

                        <div class="switch-plan">
                            
                            <div class="d-inline-flex align-items-center">
                                <div class="period">Monthly</div>
                                <a href="#" class="period-toggle js-period-toggle"></a>
                                <div class="period"><span class="mr-2">Yearly</span><span class="save-percent">Save 25%</span></div>
                            </div>

                        </div>
                    </div>
                    

                    <div class="row">
                        <?php
                        if(is_array($boxes)){
                            foreach($boxes as $box){
                                $box_plan_title   = isset($box['plan_title']) ? $box['plan_title'] : '';
                                $box_plan_content   = isset($box['box_content']) ? $box['box_content'] : '';
                                $box_plan_budget_monthly   = isset($box['plan_price_monthly']) ? $box['plan_price_monthly'] : '';
                                $box_plan_budget_yearly   = isset($box['plan_price_yearly']) ? $box['plan_price_yearly'] : '';
                                $box_plan_content_one_class   = isset($box['plan_box_one_class']) ? $box['plan_box_one_class'] : '';
                                $box_plan_content_one_benefit   = isset($box['plan_benefit_content_one']) ? $box['plan_benefit_content_one'] : '';
                                $box_plan_content_two_class  = isset($box['plan_box_two_class']) ? $box['plan_box_two_class'] : '';
                                $box_plan_content_two_benefit   = isset($box['plan_benefit_content_two']) ? $box['plan_benefit_content_two'] : '';
                                $box_link   = isset($box['plan_box_link']) ? $box['plan_box_link'] : '';
                                ?>
                                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="0">
                                    <div class="pricing-item ">
                                        <h3><?php echo esc_html($box_plan_title); ?></h3>
                                        <div class="description">
                                            <p><?php echo esc_html($box_plan_content); ?></p>
                                        </div>
                                    <div class="period-change mb-4 d-block">
                                        <div class="price-wrap">
                                        <div class="price">
                                            <div>
                                            <div><?php echo esc_html($box_plan_budget_monthly); ?></div>
                                            <div><?php echo esc_html($box_plan_budget_yearly); ?></div>
                                            </div>
                                        </div>
                                        </div>
                                        <div class="d-inline-flex align-items-center text-center period-wrap">
                                        <div class="d-inline-block mr-1"><?php echo esc_attr('per', 'append-helper'); ?></div>
                                        <div class="d-block text-left period">
                                            <div>
                                            <div><?php echo esc_html('Month','append-helper'); ?></div>
                                            <div><?php echo esc_html('Year','append-helper'); ?></div>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                    <ul class="list-unstyled mb-4">
                                        <li class="d-flex"><span class="<?php echo esc_attr($box_plan_content_one_class); ?>"></span><span><?php echo esc_html($box_plan_content_one_benefit); ?></span></li>
                                        <li class="d-flex"><span class="<?php echo esc_attr($box_plan_content_two_class); ?>"></span><span><?php echo esc_html($box_plan_content_two_benefit); ?></span></li>
                                    </ul>
                                    <div>
                                        <a href="<?php echo esc_attr($box_link); ?>" class="btn btn-primary">Get Started</a>
                                    </div>
                                    </div>
                                </div>
                                <?php

                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
              
		<?php
    }

}


?>