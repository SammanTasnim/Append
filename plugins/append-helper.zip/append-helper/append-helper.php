<?php 
/**
 * Plugin Name:       Append Helper
 * Plugin URI:        https://wordpress.org/photoshoot-core
 * Description:       Helper plugin for our proshoot theme
 * Version:           1.0.0
 * Requires at least: 4.7
 * Requires PHP:      7.2
 * Author:            Samman Tasnim
 * Author URI:        https://author.example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       append-helper
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * The code that runs during plugin activation.
 */
function append_helper_activate() {
	
}
register_activation_hook( __FILE__, 'append_helper_activate' );

/**
 * The code that runs during plugin deactivation.
 */
function append_helper_deactivate() {
	
}
register_deactivation_hook( __FILE__, 'append_helper_deactivate' );



function append_helper_load_plugin_textdomain() {

    load_plugin_textdomain(
        'append-helper',
        false,
        __DIR__ . '/languages/'
    );

}
add_action( 'plugins_loaded', 'append_helper_load_plugin_textdomain' );



// Project custom post about type

function append_cpt() {
    $args = array(
        'labels' => array(
            'name'           => __('About Page', 'append-helper'),
            'singular_name'  => __('About', 'append-helper'),
            'add_new_item'   => __('Add new About Page', 'append-helper'),
            'edit_item'      => __('Edit Page', 'append-helper'),
            'item_updated'   => __('Page updated', 'append-helper'),
            'item_published' => __('Page published', 'append-helper'),
        ),
        'hierarchical' => false,
        'public'       => true,
        'has_archive'  => false,
        'supports'     => array('thumbnail', ),
        'rewrite'      => array(
            'slug'     => 'about'
        )
    );
    register_post_type( 'about', $args );


    // create custom taxonomy
    
 
    register_taxonomy( 'about-category', array( 'about' ), $args );

}
add_action('init', 'append_cpt');



// Custom post type portfolio

function append_cpt2() {
    $args = array(
        'labels' => array(
            'name'           => __('Portfolio Page', 'append-helper'),
            'singular_name'  => __('Portfolio', 'append-helper'),
            'add_new_item'   => __('Add new Portfolio Page', 'append-helper'),
            'edit_item'      => __('Edit Page', 'append-helper'),
            'item_updated'   => __('Page updated', 'append-helper'),
            'item_published' => __('Page published', 'append-helper'),
        ),
        'hierarchical' => true,
        'public'       => true,
        'has_archive'  => false,
        'supports'     => array('thumbnail', 'title', 'editor' ),
        'rewrite'      => array(
            'slug'     => 'portfolio'
        )
    );
    register_post_type( 'portfolio', $args );


    // create custom taxonomy
    
 
    register_taxonomy( 'about-category', array( 'portfolio' ), $args );

}
add_action('init', 'append_cpt2');



//Cmb2 social  metabox
function cmb2_add_metabox() {

	$prefix = '_append_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'social_icon_section',
		'title'        => __( 'Social Icon section', 'append-helper' ),
		'object_types' => array( 'post' ),
		'context'      => 'normal',
		'show_on'      => array( 'key' => 'page', 'value' => 'single.php' ),
		'priority'     => 'default',
	) );

	$cmb->add_field( array(
		'name' => __( 'subtitle', 'append-helper' ),
		'id' => $prefix . 'text',
		'type' => 'text',
	) );


	$boxes = $cmb->add_field( array(
		'name' => __( 'Social Boxes', 'append-helper' ),
		'id' => $prefix . 'boxes_class',
		'type' => 'group',
	) );

	$cmb->add_group_field($boxes,  array(
		'name' => __( 'Icon Class', 'append-helper' ),
		'id' => $prefix . 'social_icon_class',
		'type' => 'text',
	) );

}
add_action( 'cmb2_init', 'cmb2_add_metabox' );


//CMB2 for portfolio page





//CMB2 info For Contact Us Temp

function cmb2_add_metabox_contact_info() {

	$prefix = '_append_';

	$cmb = new_cmb2_box( array(
		'id'           => $prefix . 'contact_info_section',
		'title'        => __( 'Contact Info Section', 'append-helper' ),
		'object_types' => array( 'page' ),
		'context'      => 'normal',
		'show_on'      => array( 'key' => 'page-template', 'value' => 'page-templates/contact-us-template.php' ),
		'priority'     => 'default',
	) );

	$cmb->add_field( array(
		'name' => __( 'Contact Form Shortcode', 'append-helper' ),
		'id' => $prefix . 'contact_form',
		'type' => 'text',
	) );

	$boxes_info = $cmb->add_field( array(
		'name' => __( 'Social Boxes', 'append-helper' ),
		'id' => $prefix . 'boxes_info_class',
		'type' => 'group',
	) );

	$cmb->add_group_field($boxes_info,  array(
		'name' => __( 'Icon Class', 'append-helper' ),
		'id' => $prefix . 'info_icon_class',
		'type' => 'text',
	) );
	$cmb->add_group_field($boxes_info,  array(
		'name' => __( 'Contact Information', 'append-helper' ),
		'id' => $prefix . 'info_text_class',
		'type' => 'textarea',
	) );

}
add_action( 'cmb2_init', 'cmb2_add_metabox_contact_info' );




//elementor
// register elementor widgets
function append_helper_elementor_widgets($widgets_manager) {
    require_once plugin_dir_path( __FILE__ ) . 'elementor-widgets/service-widget.php';
	require_once plugin_dir_path( __FILE__ ) . 'elementor-widgets/client-widget.php';
	require_once plugin_dir_path( __FILE__ ) . 'elementor-widgets/features-widget.php';
	require_once plugin_dir_path( __FILE__ ) . 'elementor-widgets/plans-widget.php';
	require_once plugin_dir_path( __FILE__ ) . 'elementor-widgets/testimonials-widget.php';


    $widgets_manager->register(new Append_Service_Widget());
	$widgets_manager->register(new Append_Client_Widget());
	$widgets_manager->register(new Append_Features_Widget());
	$widgets_manager->register(new Append_Plans_Widget());
	$widgets_manager->register(new Append_Testimonials_Widget());
}
add_action('elementor/widgets/register', 'append_helper_elementor_widgets');



//Redux framework


    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    $opt_name = 'append_options';

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        'display_name'         => $theme->get( 'Name' ),
        'display_version'      => $theme->get( 'Version' ),
        'menu_title'           => esc_html__( 'Append settings', 'append-helper' ),
        'customizer'           => true,
    );

    Redux::set_args( $opt_name, $args );

    Redux::set_section( $opt_name, array(
        'title'  => esc_html__( 'Basic Field', 'append-helper' ),
        'id'     => 'basic',
        'desc'   => esc_html__( 'Basic field with no subsections.', 'append-helper' ),
        'icon'   => 'el el-home',
        'fields' => array(
            array(
                'id'       => 'opt-text',
                'type'     => 'text',
                'title'    => esc_html__( 'Example Text', 'append-helper' ),
                'desc'     => esc_html__( 'Example description.', 'append-helper' ),
                'subtitle' => esc_html__( 'Example subtitle.', 'append-helper' ),
                'hint'     => array(
                    'content' => 'This is a <b>hint</b> tool-tip for the text field.<br/><br/>Add any HTML based text you like here.',
                )
			),
			array(
				'id' => 'header_image',
				'type' => 'media',
				'title' => __( 'Header Image' , 'append-helper' ),
				'desc' => __( 'Set your Header Image Here' , 'append-helper' )
			) 
        )
    ) );

?>





